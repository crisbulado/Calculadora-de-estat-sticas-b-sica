// scripts/calculadora-texto.js

document.addEventListener("DOMContentLoaded", () => {
  const input = document.querySelector(".display");
  const buttons = document.querySelectorAll(".calculator-button");

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const text = input.value.trim();
      const words = text.toLowerCase().match(/\b[\wÀ-ÿ']+\b/g) || [];

      switch (button.textContent) {
        case "Total Caracteres":
          alert(`Total de caracteres: ${text.length}`);
          break;

        case "Total Palavras":
          alert(`Total de palavras: ${words.length}`);
          break;

        case "Palavras Únicas":
          const uniqueWords = [...new Set(words)];
          alert(`Palavras únicas: ${uniqueWords.length}`);
          break;

        case "Palavras Repetidas":
          const wordCounts = countWords(words);
          const repeated = Object.entries(wordCounts).filter(([_, count]) => count > 1);
          if (repeated.length === 0) {
            alert("Nenhuma palavra repetida.");
          } else {
            const repeatedList = repeated
              .map(([word, count]) => `${word}: ${count} vezes`)
              .join("\n");
            alert(`Palavras repetidas:\n${repeatedList}`);
          }
          break;

        case "Palavras Mais Longa":
          const longest = getExtremeWord(words, "longest");
          alert(`Palavra mais longa: ${longest}`);
          break;

        case "Palavras Mais Curta":
          const shortest = getExtremeWord(words, "shortest");
          alert(`Palavra mais curta: ${shortest}`);
          break;

        case "Ocorrência":
          const freqList = Object.entries(countWords(words))
            .map(([word, count]) => `${word}: ${count}`)
            .join("\n");
          alert(`Frequência de ocorrência:\n${freqList}`);
          break;
      }
    });
  });
});

function clearDisplay() {
  document.querySelector(".display").value = "";
}

// Função para contar as ocorrências de palavras
function countWords(words) {
  const counts = {};
  for (const word of words) {
    counts[word] = (counts[word] || 0) + 1;
  }
  return counts;
}

// Função para encontrar palavra mais longa ou mais curta
function getExtremeWord(words, type = "longest") {
  if (words.length === 0) return "Nenhuma palavra";
  return words.reduce((a, b) =>
    (type === "longest" ? b.length > a.length : b.length < a.length) ? b : a
  );
}
