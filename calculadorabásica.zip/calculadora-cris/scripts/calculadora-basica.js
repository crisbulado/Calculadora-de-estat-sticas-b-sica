// Seleciona o campo de entrada
const display = document.querySelector(".display");
const calculateButton = document.querySelector(".submit-button");

// Adiciona texto ao display
function appendToDisplay(value) {
  display.value += value;
}

// Limpa o display
function clearDisplay() {
  display.value = "";
}

// Apaga o último caractere
function eraseLast() {
  display.value = display.value.slice(0, -1);
}

// Calcula a expressão
function calculate() {
  try {
    let result = eval(display.value);
    display.value = result;
  } catch (error) {
    display.value = "Erro";
  }
}

// Eventos
calculateButton.addEventListener("click", calculate);

// Recursos especiais adicionais (x², 1/x, √x, +/-)
function square() {
  try {
    let value = parseFloat(display.value);
    display.value = value * value;
  } catch {
    display.value = "Erro";
  }
}

function reciprocal() {
  try {
    let value = parseFloat(display.value);
    display.value = 1 / value;
  } catch {
    display.value = "Erro";
  }
}

function squareRoot() {
  try {
    let value = parseFloat(display.value);
    display.value = Math.sqrt(value);
  } catch {
    display.value = "Erro";
  }
}

function toggleSign() {
  try {
    let value = parseFloat(display.value);
    display.value = -value;
  } catch {
    display.value = "Erro";
  }
}

// Mapeia os botões que precisam função direta
document.querySelectorAll(".calculator-button").forEach(button => {
  const text = button.innerText.trim();
  switch (text) {
    case "x²":
      button.onclick = square;
      break;
    case "1/x":
      button.onclick = reciprocal;
      break;
    case "√x":
      button.onclick = squareRoot;
      break;
    case "+/-":
      button.onclick = toggleSign;
      break;
  }
});
