// Seletores
const display = document.querySelector('.display');
const calcButtons = document.querySelectorAll('.calculator-option-button');
const submitButton = document.querySelector('.submit-button');

// Adiciona número ao display
function appendToDisplay(value) {
  display.value += value;
}

// Limpa o display
function clearDisplay() {
  display.value = '';
}

// Apaga o último caractere
function eraseLast() {
  display.value = display.value.slice(0, -1);
}

// Função auxiliar: converter string de entrada em array de números
function parseNumbers(input) {
  return input
    .split(/[^0-9.-]+/) // separa por tudo que não for número ou ponto ou hífen
    .filter(val => val !== '' && !isNaN(val))
    .map(Number);
}

// Funções estatísticas
function calcularMedia(numeros) {
  const soma = numeros.reduce((acc, num) => acc + num, 0);
  return soma / numeros.length;
}

function calcularMediana(numeros) {
  const ordenados = [...numeros].sort((a, b) => a - b);
  const meio = Math.floor(ordenados.length / 2);
  return ordenados.length % 2 === 0
    ? (ordenados[meio - 1] + ordenados[meio]) / 2
    : ordenados[meio];
}

function calcularModa(numeros) {
  const freq = {};
  numeros.forEach(num => {
    freq[num] = (freq[num] || 0) + 1;
  });
  const maxFreq = Math.max(...Object.values(freq));
  const modas = Object.keys(freq)
    .filter(num => freq[num] === maxFreq)
    .map(Number);
  return modas.length === numeros.length ? "Sem moda" : modas.join(', ');
}

function calcularMinimo(numeros) {
  return Math.min(...numeros);
}

function calcularMaximo(numeros) {
  return Math.max(...numeros);
}

function calcularSoma(numeros) {
  return numeros.reduce((acc, num) => acc + num, 0);
}

// Aciona cálculo ao clicar nos botões de opção
calcButtons.forEach(button => {
  button.addEventListener('click', () => {
    const operacao = button.textContent.trim();
    const numeros = parseNumbers(display.value);

    if (numeros.length === 0) {
      alert("Por favor, insira números válidos.");
      return;
    }

    let resultado;

    switch (operacao) {
      case 'Média':
        resultado = calcularMedia(numeros);
        break;
      case 'Mediana':
        resultado = calcularMediana(numeros);
        break;
      case 'Moda':
        resultado = calcularModa(numeros);
        break;
      case 'Mínimo':
        resultado = calcularMinimo(numeros);
        break;
      case 'Máximo':
        resultado = calcularMaximo(numeros);
        break;
      case 'Soma':
        resultado = calcularSoma(numeros);
        break;
      default:
        resultado = 'Operação desconhecida';
    }

    display.value = `Resultado: ${resultado}`;
  });
});

// Botão "Calcular" (padrão: mostra todas as estatísticas)
submitButton.addEventListener('click', () => {
  const numeros = parseNumbers(display.value);
  if (numeros.length === 0) {
    alert("Por favor, insira números válidos.");
    return;
  }

  const estatisticas = `
Média: ${calcularMedia(numeros)}
Mediana: ${calcularMediana(numeros)}
Moda: ${calcularModa(numeros)}
Mínimo: ${calcularMinimo(numeros)}
Máximo: ${calcularMaximo(numeros)}
Soma: ${calcularSoma(numeros)}
  `.trim();

  display.value = estatisticas;
});
